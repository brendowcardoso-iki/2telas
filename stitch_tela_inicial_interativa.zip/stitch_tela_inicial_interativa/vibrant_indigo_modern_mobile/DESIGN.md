---
name: Vibrant Indigo Modern Mobile
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#005e6e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00788c'
  on-tertiary-container: '#d7f6ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.015em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

O design system estabelece uma experiência de primeiro impacto contemporânea, confiante e envolvente para telas de acolhimento (splash/welcome screen). A atmosfera visual equilibra modernidade funcional com sofisticação gráfica, projetada especificamente para produtos digitais mobile-first que demandam clareza, dinamismo e alto valor percebido desde o primeiro segundo de interação.

### Filosofia Estética
A identidade visual funde **Minimalismo Funcional** com toques suaves de **Glassmorphism Tátil**. O foco principal reside no espaço negativo generoso, na hierarquia tipográfica assertiva e na profundidade luminosa proporcionada pelo gradiente sutil entre azul elétrico e índigo profundo. A interface transmite segurança técnica, inovação e acolhimento imediato, eliminando ruídos visuais para focar na mensagem central e nas ações primárias de conversão (onboarding, login e cadastro).

## Colors

A arquitetura cromática é alicerçada na interação dinâmica entre tons frios de alta energia e superfícies neutras acetinadas:

- **Primary (`#2563EB` - Royal Blue Vibrant):** O motor de ação principal. Conduz a atenção do usuário para os elementos centrais de engajamento, transmitindo dinamismo, precisão e estabilidade.
- **Secondary (`#4F46E5` - Deep Indigo):** Confere profundidade e nobreza editorial. Utilizado em harmonia com a cor primária para criar gradientes sutis de alta energia em botões hero, ícones de destaque e detalhes de branding.
- **Tertiary (`#06B6D4` - Vivid Cyan):** Funciona como um acento luminoso para micro-detalhes, pontos de paginação ativa (carousel dots), badges e efeitos de brilho suave (glow highlights).
- **Neutral (`#0F172A` - Slate Nocturne):** Estrutura a leitura em textos de máximo contraste, mantendo calor ótico sem a dureza do preto puro (`#000000`).

### Superfícies e Tons de Fundo
- **Background Base:** `#F8FAFC` (Off-white fresco que evita fadiga ocular).
- **Surface Layer 1:** `#FFFFFF` (Branco absoluto para cards flutuantes e modais de entrada).
- **Surface Muted:** `#EDF2F7` (Base suave para inputs desativados e contornos discretos).
- **Text Muted:** `#64748B` (Cinza médio para termos de serviço, legendas e rótulos secundários).

## Typography

A família **Plus Jakarta Sans** foi selecionada como voz tipográfica unificada para toda a interface. Com proporções geométricas equilibradas, terminações arejadas e excelente legibilidade em pequenas escalas em displays Retina e OLED, ela entrega uma expressividade amigável sem perder o caráter moderno e tecnológico.

- **Títulos e Acolhimento (`display-hero-mobile`, `headline-lg`):** Devem ser diagramados com tracking negativo estreito (`-0.02em` a `-0.03em`) para compor blocos de texto coesos, escaneáveis e impactantes.
- **Corpo (`body-lg`, `body-md`):** Garante ritmo de leitura ágil para subtítulos explicativos de onboarding, com line-height generoso que assegura respiro.
- **Rótulos e Botões (`label-lg`, `label-md`):** Tipografia intencionalmente reforçada com peso semibold (600) ou bold (700), otimizando a taxa de clique e a nitidez em botões com fundos saturados.

## Layout & Spacing

O layout adota uma abordagem de grade fluida adaptada à ergonomia móvel, com divisão rítmica baseada em incrementos de 4px e 8px:

- **Margens de Tela:** `1.5rem` (24px) de margem lateral estrita para criar respiro visual seguro em aparelhos móveis sem encroaching nas bordas do aparelho ou Dynamic Island / Notch.
- **Zona de Interação (Thumb Zone):** Na tela inicial/welcome screen, a hierarquia vertical distribui os elementos visuais de marca (logotipo, ilustrações conceituais ou elementos 3D com blur) nos 60% superiores, enquanto o bloco funcional de ação (botões primário, secundário, login social e links legais) ocupa os 40% inferiores, permitindo operação natural com uma só mão.
- **Espaçamento entre Ações:** Espaçamento vertical estrito de `space-sm` (8px) a `space-md` (16px) entre botões empilhados para evitar toques acidentais e manter coesão de grupo.

## Elevation & Depth

A profundidade é expressa através de **sombras ambiente coloridas** e **camadas translúcidas com desfoque de fundo (backdrop-filter)**:

1. **Botões de Ação Principal (Primary Buttons):**
   - Utilizam sombra projetada matizada pelo azul índigo: `box-shadow: 0 10px 24px -4px rgba(37, 99, 235, 0.35), 0 4px 8px -2px rgba(79, 70, 229, 0.20)`. Isso cria a sensação de que o elemento levita e emite energia sobre o fundo claro.
2. **Cards Flutuantes e Superfícies (Welcome Containers):**
   - Superfícies com `background: rgba(255, 255, 255, 0.85)`, apoiadas por `backdrop-filter: blur(16px)` e borda sutil de `1px solid rgba(255, 255, 255, 0.6)`.
   - Sombra ambiente neutra e difusa: `box-shadow: 0 20px 40px -12px rgba(15, 23, 42, 0.08)`.
3. **Padrão de Fundo Difuso (Atmospheric Glow):**
   - A tela de boas-vindas recebe orbes de gradiente azul e índigo desfocados (`filter: blur(80px); opacity: 0.15`) no topo superior direito e centro inferior, conferindo riqueza tridimensional sem obstruir o contraste tipográfico.

## Shapes

O sistema utiliza a escala **`2` (Rounded)**, equilibrando suavidade visual contemporânea e rigor geométrico:

- **Componentes Interativos Pequenos a Médios:** `rounded` (0.5rem / 8px) para checkboxes, chips e badges auxiliares.
- **Campos de Formulário e Contêineres Menores:** `rounded-lg` (1rem / 16px) para garantir sensação amigável e confortável ao toque.
- **Botões Hero Primários:** Podem transitar de `rounded-lg` (16px) até a aplicação semi-pill para conferir apelo de convite irrestrito à ação.
- **Cards e Sheets de Apresentação:** `rounded-xl` (1.5rem / 24px) no topo de bottom-sheets ou em modais de onboarding, refletindo os raios de cantos arredondados de hardware dos dispositivos mais recentes.

## Components

### 1. Botões de Destaque (CTA Primário & Secundário)
- **Primary Hero Button:** Altura mínima de 56px para conformidade touch target. Preenchimento em gradiente linear sutil de 135deg (`linear-gradient(135deg, #2563EB 0%, #4F46E5 100%)`). Tipografia `label-lg` na cor branca absoluta (`#FFFFFF`). Leve brilho interno (`inset 0 1px 0 rgba(255,255,255,0.2)`) e sombra colorida proeminente. Ao toque (active state), escala sutil para `scale(0.98)`.
- **Secondary / Ghost Button:** Fundo transparente com borda de 1.5px em `#E2E8F0` ou preenchimento neutro translúcido (`rgba(15, 23, 42, 0.04)`). Texto em cor primária `#2563EB` ou neutra `#0F172A`. Ideal para opções como "Explorar como visitante" ou "Fazer Login".
- **Social Auth Buttons:** Fundo branco puro, borda sutil de 1px em `#E2E8F0`, ícone alinhado à esquerda com peso visual equilibrado e tipografia `label-md` centralizada em tom `#0F172A`.

### 2. Indicadores de Passo / Paginação (Carousel Dots)
- Utilizados em slides de apresentação no welcome screen.
- Ponto inativo: Círculo de 8px x 8px, cor `#CBD5E1`.
- Ponto ativo: Pílula expandida de 24px x 8px com preenchimento em gradiente azul-índigo, com transição fluida de largura via interpolação elástica (`cubic-bezier(0.4, 0, 0.2, 1)`).

### 3. Campos de Entrada (Input Fields)
- Altura base de 52px, raio de 16px (`rounded-lg`), borda de 1px em `#E2E8F0` e fundo `#FFFFFF`.
- Estado de Foco (Focus State): Borda ativa em tom `#2563EB` e anel exterior suave de foco (`box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.12)`). Ícones de prefixo em tom secundário muted.

### 4. Checkboxes & Termos de Uso
- Caixa arredondada de 20px com raio de 6px.
- Quando marcado, preenchimento pleno em `#4F46E5` com ícone de check branco centralizado. Texto de apoio diagramado em `body-sm` com links clicáveis em negrito e cor primária `#2563EB`.

### 5. Cards de Destaque / Value Proposition Cards
- Fundo em camadas translúcidas (`rgba(255,255,255,0.8)` com blur de 12px), cantos de 20px, contorno sutil de 1px em tom neutro suave.
- Acolhe ícones expressivos envoltos em um círculo de gradiente translúcido suave (`rgba(37, 99, 235, 0.1)`) para comunicar os benefícios do aplicativo antes do cadastro.